# Project Discontinued
This project has been replaced with a more flexible solution, found here : https://github.com/Jman420/magisk_selinux_manager

# magisk-permissive-script
Installs a simple script to enable Permissive Mode during Magisk Startup
